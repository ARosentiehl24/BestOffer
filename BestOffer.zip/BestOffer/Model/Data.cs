﻿namespace BestDeal.Model
{
    public class Data
    {
        public string? SourceAddress { get; set; }

        public string? DestinationAddress { get; set; }

        public double[]? Dimensions { get; set; }
    }
}
